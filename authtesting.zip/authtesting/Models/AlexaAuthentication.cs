﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Globalization;

namespace authtesting.Models
{
    public class AlexaAuthentication
    {
        string str = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;
        public List<Authentication> GetAuthUsers(int Userid)
        {
            using (SqlConnection con = new SqlConnection(str))
            {
                List<Authentication> lstusers = new List<Authentication>();

                con.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexaGetUsers", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@userid", Userid);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        while (sdr.Read())
                        {
                            lstusers.Add(new Authentication
                            {
                                Userid = Convert.ToInt16(sdr["Usr_UserID"]),
                                Firstname = sdr["UsrP_FirstName"].ToString(),
                                Lastname = sdr["UsrP_LastName"].ToString()
                            });
                        }
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return lstusers;
            }

        }
        public Authentication GetUsers(string deviceid)
        {
            Authentication lstusers = new Authentication();
            SqlConnection con = new SqlConnection(str);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("AlexaGetUserDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@deviceid", deviceid);
               
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                    while (sdr.Read())
                    {
                        lstusers = new Authentication
                        {
                            Userid = Convert.ToInt16(sdr["Usr_UserID"]),
                            Firstname = sdr["UsrP_FirstName"].ToString(),
                            Lastname = sdr["UsrP_LastName"].ToString(),
                           
                        };
                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstusers;
        }
        public GetHolidays GetHours(int month, string deviceid/*string phonenumber,*/)
        {

            using (SqlConnection con = new SqlConnection(str))
            {
                GetHolidays objholidays = new GetHolidays();


                con.Open();
                try
                {
                    objholidays.lstholidays = new List<HolidayCalender>();

                    SqlCommand cmd = new SqlCommand("AlexaGetWorkingHoursDetails", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@month", month);
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                   
                    // cmd.Parameters.AddWithValue("@pin", pin);
                    //cmd.Parameters.AddWithValue("@status", SqlDbType.Int);
                    cmd.ExecuteNonQuery();
                    //cmd.Parameters["@status"].Direction = ParameterDirection.Output;


                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);

                    //if (cmd.Parameters["@status"].Value != null)
                    //    objholidays.Status = Int32.Parse(cmd.Parameters["@status"].Value.ToString());

                    //if (cmd.Parameters["@status"].Value != null)
                    //    objholidays.Status = Convert.ToInt32(cmd.Parameters["@status"].Value);

                    //Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
                   
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        objholidays.FirstName = dr["UsrP_FirstName"].ToString();
                    }

                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        //    DateTime dt = DateTime.ParseExact( dr["HolidayDate"].ToString(), "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);

                        //  string s = dt.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);
                        objholidays.lstholidays.Add(new HolidayCalender
                        {
                            Holidayname = dr["Holidayname"].ToString(),
                            // HolidayDate=Convert.ToDateTime(dr["HolidayDate"])
                            //    HolidayDate = s
                            HolidayDate = Convert.ToDateTime(dr["HolidayDate"]).ToShortDateString()
                        });

                    }
                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {

                        objholidays.HolidaysCount = Convert.ToInt16(dr["holidayscount"]);
                    }
                    foreach (DataRow dr in ds.Tables[3].Rows)
                    {

                        objholidays.Workingdays = Convert.ToInt16(dr["WorkingDays"]);
                    }

                    foreach (DataRow dr in ds.Tables[4].Rows)
                    {
                        objholidays.Workinghours = Convert.ToInt16(dr["WorkingHours"]);
                    }
                    foreach (DataRow dr in ds.Tables[5].Rows)
                    {

                        objholidays.TimesheetMonth = Convert.ToDateTime(dr["TimesheetMonth"]).ToShortDateString();
                        //objholidays.TimesheetMonth = DateTime.da
                    }

                    //if(objholidays.Status==0)
                    //{
                    //    objholidays.Status = 0;
                    //}
                    //if (objholidays.Status == 1)
                    //{
                    //    objholidays.Status = 1;
                    //}
                    //if (objholidays.Status == 2)
                    //{
                    //    objholidays.Status = 2;
                    //}
                    //if (objholidays.Status == 3)
                    //{
                    //    objholidays.Status = 3;
                    //}
                }

                catch (Exception ex)
                {
                    throw ex;
                }
                return objholidays;
            }
        }

        public SubmitTimesheet GetTimeSheet(int month, string deviceid /*string phonenumber,*/)
        {
            using (SqlConnection con = new SqlConnection(str))
            { 
                con.Open();
                SubmitTimesheet objtimesheet = new SubmitTimesheet();
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexaSubmitTimesheetdetails", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Month", month);
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                    
                    // cmd.Parameters.AddWithValue("@pin", pin);
                    cmd.Parameters.AddWithValue("@timesheetSubmitted", SqlDbType.Int);
                    cmd.Parameters.AddWithValue("@workinghours", SqlDbType.Int);

                    cmd.Parameters["@timesheetSubmitted"].Direction = ParameterDirection.Output;
                    cmd.Parameters["@workinghours"].Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    //SqlDataReader sdr = cmd.ExecuteReader();
                    if (cmd.Parameters["@timesheetSubmitted"].Value != null)
                        objtimesheet.Timesheetstatus = Int32.Parse(cmd.Parameters["@timesheetSubmitted"].Value.ToString());
                    if (cmd.Parameters["@workinghours"].Value != null)
                        objtimesheet.GetWorkingHours = Int32.Parse(cmd.Parameters["@workinghours"].Value.ToString());

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return objtimesheet;
            }
        }
        public StatusFlags CheckStatus(string Deviceid)
        {

            using (SqlConnection con = new SqlConnection(str))
            {
                StatusFlags objflags = new StatusFlags();

                int flag = -1;
                con.Open();
                try
                {
                   

                    SqlCommand cmd = new SqlCommand("AlexaCheckStatus", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    cmd.Parameters.AddWithValue("@deviceid", Deviceid);

                    // cmd.Parameters.AddWithValue("@pin", pin);
                    cmd.Parameters.AddWithValue("@status", SqlDbType.Int);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters["@status"].Direction = ParameterDirection.Output;


                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);

                    if (cmd.Parameters["@status"].Value != null)
                        flag = Int32.Parse(cmd.Parameters["@status"].Value.ToString());
                    if(flag==0)
                    {
                        objflags.Response = "Not Submitted";
                    }
                    if(flag==1)
                    {
                        objflags.Response = "Not Approved";
                    }
                    if (flag == 2)
                    {
                        objflags.Response = "Approved";
                    }
                    if (flag == 3)
                    {
                        objflags.Response = "Rejected";
                    }

                    //if (cmd.Parameters["@status"].Value != null)
                    //    objholidays.Status = Convert.ToInt32(cmd.Parameters["@status"].Value);

                    //Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");


                }

                catch (Exception ex)
                {
                    throw ex;
                }
                return objflags;
              
            }
        }
        public Devices InsertDeviceId(string deviceId)
        {
            using (SqlConnection con = new SqlConnection(str))
            {


                Devices device = new Devices();
                try
                {
                    SqlCommand cmd = new SqlCommand("getdeviceID", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DeviceId", deviceId);
                    con.Open();
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return device;
            }
        }
        public FetchUsers FetchData(string deviceid)
        {
            using (SqlConnection con = new SqlConnection(str))
            {
                FetchUsers objusers = new FetchUsers();
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexaWakeUpProc", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    // if(sdr.Read())
                    {
                        return (sdr.Read()) ? new FetchUsers
                        {
                            Name = sdr["Titleprefix"].ToString() + " " + sdr["UsrP_FirstName"].ToString() + " " + sdr["UsrP_LastName"].ToString(),
                            Mobilenumber = sdr["Usrp_MobileNumber"].ToString(),
                            Status = (sdr != null) ? 1 : 0
                        } : new FetchUsers
                        {
                            Name = string.Empty,
                            Mobilenumber = string.Empty,
                            Status = 0
                        };
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // return objusers;
            }
        }
        public HelloMessage ValidateUser(string deviceid, string phonenumber/*,string pin*/)
        {

            using (SqlConnection con = new SqlConnection(str))
            {
                HelloMessage objmessage = new HelloMessage();
                int status = 0;
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexaValidateUser", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                    cmd.Parameters.AddWithValue("@phnumber", phonenumber);
                    // cmd.Parameters.AddWithValue("@pin", pin);
                    cmd.Parameters.AddWithValue("@message", SqlDbType.Int);
                    cmd.Parameters["@message"].Direction = ParameterDirection.Output;
                    int i = cmd.ExecuteNonQuery();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (cmd.Parameters["@message"].Value != null)
                        status = Int32.Parse(cmd.Parameters["@message"].Value.ToString());

                    if (status == 1)
                    {
                        objmessage.Message = ResponseCodes.Exits;
                    }


                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return objmessage;
            }
        }
        public ValidatePhoneClass ValidatePhone(string deviceid, string phonenumber)
        {

            using (SqlConnection con = new SqlConnection(str))
            {
                ValidatePhoneClass objmessage = new ValidatePhoneClass();
                int status = 0;
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexavalidatePhone", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                    cmd.Parameters.AddWithValue("@phnumber", phonenumber);
                    cmd.Parameters.AddWithValue("@message", SqlDbType.Int);
                    cmd.Parameters["@message"].Direction = ParameterDirection.Output;
                    // int i = cmd.ExecuteNonQuery();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (cmd.Parameters["@message"].Value != null)
                        status = Int32.Parse(cmd.Parameters["@message"].Value.ToString());

                    //if (status == 1)
                    //{
                    //    objmessage.Phone = phonenumber;
                    //    objmessage.Flag = ResponseCodes.Exits;
                    //}
                    //else
                    //{
                    //    objmessage.Phone = phonenumber;
                    //    objmessage.Flag = ResponseCodes.NotExists;
                    //}

                    return objmessage = (status == 1) ? new ValidatePhoneClass
                    {
                        Phone = phonenumber,
                        Flag = ResponseCodes.Exits
                    } : new ValidatePhoneClass
                    {
                        Phone = phonenumber,
                        Flag = ResponseCodes.NotExists
                    };

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                //return objmessage;
            }
        }

        public Validatepinclass Validatepin(string deviceid, int pin)
        {

            using (SqlConnection con = new SqlConnection(str))
            {
                Validatepinclass objmessage = new Validatepinclass();
                int status = 0;
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexavalidatePin", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                    cmd.Parameters.AddWithValue("@pin", pin);
                    cmd.Parameters.AddWithValue("@message", SqlDbType.Int);
                    cmd.Parameters["@message"].Direction = ParameterDirection.Output;
                    // int i = cmd.ExecuteNonQuery();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (cmd.Parameters["@message"].Value != null)
                        status = Convert.ToInt32(cmd.Parameters["@message"].Value);

                    //if (status == 1)
                    //{
                    //    objmessage.Phone = phonenumber;
                    //    objmessage.Flag = ResponseCodes.Exits;
                    //}
                    //else
                    //{
                    //    objmessage.Phone = phonenumber;
                    //    objmessage.Flag = ResponseCodes.NotExists;
                    //}

                    return objmessage = (status == 1) ? new Validatepinclass
                    {
                        pin = pin,
                        Flag = ResponseCodes.Exits
                    } : new Validatepinclass
                    {
                        pin = pin,
                        Flag = ResponseCodes.NotExists
                    };

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                //return objmessage;
            }
        }
        public HelloMessage ValidatePasscode(string deviceid, string phonenumber, string pin)
        {

            using (SqlConnection con = new SqlConnection(str))
            {
                HelloMessage objmessage = new HelloMessage();
                int status = 0;
                try
                {
                    SqlCommand cmd = new SqlCommand("AlexaValidatePasscode", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@deviceid", deviceid);
                    cmd.Parameters.AddWithValue("@phnumber", phonenumber);
                    cmd.Parameters.AddWithValue("@pin", pin);
                    cmd.Parameters.AddWithValue("@message", SqlDbType.Int);
                    cmd.Parameters["@message"].Direction = ParameterDirection.Output;
                    int i = cmd.ExecuteNonQuery();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (cmd.Parameters["@message"].Value != null)
                        status = Int32.Parse(cmd.Parameters["@message"].Value.ToString());

                    if (status == 1)
                    {
                        objmessage.Message = ResponseCodes.Exits;

                    }


                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return objmessage;
            }
        }


    }
}